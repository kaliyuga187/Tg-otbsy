import React from 'react';

interface Stats {
  totalProfit: number;
  totalTrades: number;
  winRate: number;
  avgProfit: number;
  bestTrade: number;
  worstTrade: number;
  totalVolume: number;
  activePositions: number;
}

interface PerformanceStatsProps {
  stats: Stats;
}

export const PerformanceStats: React.FC<PerformanceStatsProps> = ({ stats }) => {
  const StatCard = ({ label, value, color, prefix = '', suffix = '' }: any) => (
    <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
      <div className="text-gray-400 text-sm mb-1">{label}</div>
      <div className={`text-2xl font-bold ${color}`}>
        {prefix}{value}{suffix}
      </div>
    </div>
  );

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
      <StatCard
        label="Total Profit"
        value={stats.totalProfit.toLocaleString()}
        color={stats.totalProfit >= 0 ? 'text-green-400' : 'text-red-400'}
        prefix="$"
      />
      <StatCard
        label="Win Rate"
        value={stats.winRate.toFixed(1)}
        color={stats.winRate >= 50 ? 'text-green-400' : 'text-yellow-400'}
        suffix="%"
      />
      <StatCard
        label="Total Trades"
        value={stats.totalTrades}
        color="text-blue-400"
      />
      <StatCard
        label="Active Positions"
        value={stats.activePositions}
        color="text-purple-400"
      />
      <StatCard
        label="Average Profit"
        value={stats.avgProfit.toFixed(2)}
        color={stats.avgProfit >= 0 ? 'text-green-400' : 'text-red-400'}
        prefix="$"
      />
      <StatCard
        label="Best Trade"
        value={stats.bestTrade.toLocaleString()}
        color="text-green-400"
        prefix="$"
      />
      <StatCard
        label="Worst Trade"
        value={stats.worstTrade.toLocaleString()}
        color="text-red-400"
        prefix="$"
      />
      <StatCard
        label="Total Volume"
        value={(stats.totalVolume / 1000).toFixed(1)}
        color="text-cyan-400"
        suffix="K"
      />
    </div>
  );
};