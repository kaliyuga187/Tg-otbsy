import React, { useState } from 'react';

interface TelegramBotProps {
  isConnected: boolean;
  onConnect: (token: string) => void;
  onDisconnect: () => void;
  commands: string[];
}

export const TelegramBot: React.FC<TelegramBotProps> = ({
  isConnected,
  onConnect,
  onDisconnect,
  commands
}) => {
  const [botToken, setBotToken] = useState('');
  const [showCommands, setShowCommands] = useState(false);

  const handleConnect = () => {
    if (botToken) {
      onConnect(botToken);
    }
  };

  return (
    <div className="bg-gray-900 rounded-lg p-6 border border-gray-800">
      <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
        <span className="mr-3">🤖</span> Telegram Bot Control
      </h2>

      {!isConnected ? (
        <div className="space-y-4">
          <div>
            <label className="block text-gray-400 text-sm mb-2">Bot Token</label>
            <input
              type="password"
              placeholder="Enter your Telegram bot token"
              value={botToken}
              onChange={(e) => setBotToken(e.target.value)}
              className="w-full bg-gray-800 text-white rounded px-4 py-2 border border-gray-700 focus:border-green-500 focus:outline-none"
            />
          </div>
          <button
            onClick={handleConnect}
            className="w-full bg-green-600 hover:bg-green-500 text-white py-3 rounded font-bold transition-colors"
          >
            Connect Telegram Bot
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="bg-green-900 border border-green-700 rounded p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse mr-3"></div>
                <span className="text-green-400 font-bold">Bot Connected</span>
              </div>
              <button
                onClick={onDisconnect}
                className="bg-red-600 hover:bg-red-500 text-white px-4 py-2 rounded text-sm font-bold transition-colors"
              >
                Disconnect
              </button>
            </div>
          </div>

          <div>
            <button
              onClick={() => setShowCommands(!showCommands)}
              className="w-full bg-gray-800 hover:bg-gray-700 text-white py-3 rounded font-bold transition-colors flex items-center justify-between px-4"
            >
              <span>Available Commands</span>
              <span>{showCommands ? '▲' : '▼'}</span>
            </button>

            {showCommands && (
              <div className="mt-4 space-y-2">
                {commands.map((cmd, index) => (
                  <div key={index} className="bg-gray-800 rounded p-3">
                    <code className="text-green-400">{cmd}</code>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-gray-800 rounded p-4">
            <h3 className="text-white font-bold mb-2">Bot Statistics</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-400">Messages Sent:</span>
                <span className="text-white ml-2">1,247</span>
              </div>
              <div>
                <span className="text-gray-400">Alerts Triggered:</span>
                <span className="text-white ml-2">89</span>
              </div>
              <div>
                <span className="text-gray-400">Active Users:</span>
                <span className="text-white ml-2">12</span>
              </div>
              <div>
                <span className="text-gray-400">Uptime:</span>
                <span className="text-white ml-2">99.8%</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};