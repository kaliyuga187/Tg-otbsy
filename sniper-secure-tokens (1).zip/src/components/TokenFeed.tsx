import React, { useState, useEffect } from 'react';
import { TokenMetrics } from '../utils/tokenAnalyzer';

interface TokenFeedProps {
  tokens: TokenMetrics[];
  onRefresh: () => void;
  isLoading: boolean;
}

export const TokenFeed: React.FC<TokenFeedProps> = ({ tokens, onRefresh, isLoading }) => {
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredTokens = tokens.filter(token => {
    const matchesSearch = token.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         token.address.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (filter === 'all') return matchesSearch;
    if (filter === 'safe') return matchesSearch && token.rugScore < 30;
    if (filter === 'risky') return matchesSearch && token.rugScore >= 30;
    if (filter === 'new') return matchesSearch && Date.now() - token.timestamp < 3600000;
    return matchesSearch;
  });

  return (
    <div className="bg-gray-900 rounded-lg p-6 border border-gray-800">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center">
          <span className="mr-3">🎯</span> Live Token Feed
        </h2>
        <button
          onClick={onRefresh}
          disabled={isLoading}
          className={`px-4 py-2 rounded font-bold transition-colors ${
            isLoading 
              ? 'bg-gray-700 text-gray-500 cursor-not-allowed' 
              : 'bg-blue-600 hover:bg-blue-500 text-white'
          }`}
        >
          {isLoading ? 'Scanning...' : 'Refresh'}
        </button>
      </div>

      <div className="flex gap-4 mb-4">
        <input
          type="text"
          placeholder="Search tokens..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-1 bg-gray-800 text-white rounded px-4 py-2 border border-gray-700 focus:border-green-500 focus:outline-none"
        />
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="bg-gray-800 text-white rounded px-4 py-2 border border-gray-700 focus:border-green-500 focus:outline-none"
        >
          <option value="all">All Tokens</option>
          <option value="safe">Safe (Rug Score &lt; 30)</option>
          <option value="risky">Risky (Rug Score ≥ 30)</option>
          <option value="new">New (Last Hour)</option>
        </select>
      </div>

      <div className="overflow-y-auto max-h-96 space-y-2">
        {filteredTokens.map((token, index) => (
          <div
            key={token.address}
            className="flex items-center justify-between p-3 bg-gray-800 rounded hover:bg-gray-700 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
              <div>
                <div className="text-white font-bold">{token.symbol}</div>
                <div className="text-gray-500 text-xs">{token.address.slice(0, 8)}...</div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="text-green-400 text-sm">${token.marketCap.toLocaleString()}</div>
                <div className="text-gray-500 text-xs">MCap</div>
              </div>
              <div className="text-right">
                <div className="text-blue-400 text-sm">${token.volume24h.toLocaleString()}</div>
                <div className="text-gray-500 text-xs">Vol</div>
              </div>
              <div className={`px-2 py-1 rounded text-xs ${
                token.rugScore < 30 ? 'bg-green-900 text-green-400' : 
                token.rugScore < 60 ? 'bg-yellow-900 text-yellow-400' : 
                'bg-red-900 text-red-400'
              }`}>
                {token.rugScore}% Risk
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredTokens.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          {isLoading ? 'Scanning for new tokens...' : 'No tokens found matching criteria'}
        </div>
      )}
    </div>
  );
};