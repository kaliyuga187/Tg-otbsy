import React, { useState, useEffect } from 'react';
import { TokenCard } from './TokenCard';
import { PositionManager } from './PositionManager';
import { PerformanceStats } from './PerformanceStats';
import { SettingsPanel } from './SettingsPanel';
import { TokenFeed } from './TokenFeed';
import { TelegramBot } from './TelegramBot';
import { TokenAnalyzer, TokenMetrics } from '../utils/tokenAnalyzer';
import { MEVProtection } from '../utils/mevProtection';

const CONTRACT_ADDRESS = '0x2D77ed8F964C04D631cb3b9E8E7803e208f1E43b';

export default function AppLayout() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [tokens, setTokens] = useState<TokenMetrics[]>([]);
  const [positions, setPositions] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [botConnected, setBotConnected] = useState(false);
  
  const [stats] = useState({
    totalProfit: 12847.50,
    totalTrades: 156,
    winRate: 68.5,
    avgProfit: 82.35,
    bestTrade: 3250,
    worstTrade: -450,
    totalVolume: 45670,
    activePositions: 4
  });

  const [settings, setSettings] = useState({
    maxMarketCap: 50000,
    minLiquidity: 5000,
    maxSlippage: 10,
    autoBuyAmount: 0.5,
    stopLossPercent: 20,
    takeProfitPercent: 200,
    mevProtection: true,
    telegramAlerts: true
  });

  const mockTokens: TokenMetrics[] = [
    {
      address: '0x1234...5678',
      name: 'MoonShot',
      symbol: 'MOON',
      marketCap: 25000,
      liquidity: 8000,
      volume24h: 12000,
      holders: 45,
      priceChange: 125,
      rugScore: 15,
      mevRisk: 'low',
      timestamp: Date.now()
    },
    {
      address: '0x8765...4321',
      name: 'RocketFuel',
      symbol: 'ROCKET',
      marketCap: 35000,
      liquidity: 12000,
      volume24h: 18000,
      holders: 78,
      priceChange: 85,
      rugScore: 25,
      mevRisk: 'medium',
      timestamp: Date.now() - 1800000
    },
    {
      address: '0xabcd...efgh',
      name: 'DiamondHands',
      symbol: 'DIAMOND',
      marketCap: 18000,
      liquidity: 6500,
      volume24h: 9500,
      holders: 32,
      priceChange: 210,
      rugScore: 20,
      mevRisk: 'low',
      timestamp: Date.now() - 900000
    },
    {
      address: '0xijkl...mnop',
      name: 'SafeMoon2',
      symbol: 'SAFE2',
      marketCap: 42000,
      liquidity: 15000,
      volume24h: 22000,
      holders: 120,
      priceChange: 45,
      rugScore: 10,
      mevRisk: 'low',
      timestamp: Date.now() - 2700000
    },
    {
      address: '0xqrst...uvwx',
      name: 'GemFinder',
      symbol: 'GEM',
      marketCap: 8500,
      liquidity: 3200,
      volume24h: 4800,
      holders: 18,
      priceChange: 320,
      rugScore: 35,
      mevRisk: 'high',
      timestamp: Date.now() - 600000
    },
    {
      address: '0xyzab...cdef',
      name: 'SolarFlare',
      symbol: 'SOLAR',
      marketCap: 29000,
      liquidity: 10500,
      volume24h: 14500,
      holders: 65,
      priceChange: 92,
      rugScore: 18,
      mevRisk: 'medium',
      timestamp: Date.now() - 1200000
    }
  ];

  useEffect(() => {
    setTokens(mockTokens);
  }, []);

  const handleSnipe = async (token: TokenMetrics) => {
    if (settings.mevProtection) {
      await MEVProtection.executeWithProtection(
        { to: token.address, amount: settings.autoBuyAmount },
        'high'
      );
    }
    
    const newPosition = {
      id: Date.now().toString(),
      token: token.address,
      symbol: token.symbol,
      entryPrice: 0.000045,
      currentPrice: 0.000052,
      amount: settings.autoBuyAmount,
      pnl: 35.50,
      pnlPercent: 15.5,
      timestamp: Date.now(),
      status: 'active' as const
    };
    
    setPositions([...positions, newPosition]);
    alert(`Sniped ${token.symbol} with ${settings.autoBuyAmount} SOL!`);
  };

  const handleAnalyze = (token: TokenMetrics) => {
    const potential = TokenAnalyzer.calculateProfitPotential(token);
    alert(`${token.symbol} Profit Potential: ${potential.toFixed(2)}%`);
  };

  const handleClosePosition = (id: string) => {
    setPositions(positions.filter(p => p.id !== id));
    alert('Position closed successfully!');
  };

  const handleRefreshTokens = () => {
    setIsLoading(true);
    setTimeout(() => {
      setTokens([...mockTokens].sort(() => Math.random() - 0.5));
      setIsLoading(false);
    }, 2000);
  };

  const telegramCommands = [
    '/start - Initialize the bot',
    '/status - Check bot status',
    '/positions - View active positions',
    '/settings - Configure bot settings',
    '/snipe [token] - Manually snipe a token',
    '/close [position] - Close a position',
    '/stats - View performance stats',
    '/stop - Stop the bot'
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="bg-gray-900 border-b border-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-3xl font-bold bg-gradient-to-r from-green-400 to-purple-600 bg-clip-text text-transparent">
                Solana Sniper Bot
              </h1>
              <span className="px-3 py-1 bg-green-900 text-green-400 rounded text-sm font-bold">
                LIVE
              </span>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-sm">
                <span className="text-gray-400">Contract:</span>
                <span className="text-green-400 ml-2 font-mono">{CONTRACT_ADDRESS.slice(0, 8)}...</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-green-400">Connected</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="bg-gray-900 border-b border-gray-800">
        <div className="container mx-auto px-4">
          <div className="flex gap-6">
            {['dashboard', 'positions', 'settings', 'telegram'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-3 px-4 font-bold capitalize transition-colors ${
                  activeTab === tab
                    ? 'text-green-400 border-b-2 border-green-400'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <div className="relative h-64 overflow-hidden">
        <img 
          src="https://d64gsuwffb70l.cloudfront.net/68f0e17608197953cfdb9987_1760616868297_f297441c.webp"
          alt="Trading Terminal"
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-4xl font-bold mb-4">Snipe Early. Exit Smart. Maximize Profits.</h2>
            <p className="text-gray-400 text-lg">Advanced MEV protection and automated trading on Solana</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        {activeTab === 'dashboard' && (
          <>
            <PerformanceStats stats={stats} />
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <TokenFeed 
                tokens={tokens}
                onRefresh={handleRefreshTokens}
                isLoading={isLoading}
              />
              
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-white flex items-center">
                  <span className="mr-3">🔥</span> Hot Opportunities
                </h2>
                <div className="grid grid-cols-1 gap-4">
                  {TokenAnalyzer.filterTokens(tokens).slice(0, 3).map(token => (
                    <TokenCard
                      key={token.address}
                      token={token}
                      onSnipe={handleSnipe}
                      onAnalyze={handleAnalyze}
                    />
                  ))}
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === 'positions' && (
          <PositionManager
            positions={positions}
            onClosePosition={handleClosePosition}
            onUpdateStopLoss={() => {}}
            onUpdateTakeProfit={() => {}}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsPanel
            settings={settings}
            onSave={setSettings}
          />
        )}

        {activeTab === 'telegram' && (
          <TelegramBot
            isConnected={botConnected}
            onConnect={() => setBotConnected(true)}
            onDisconnect={() => setBotConnected(false)}
            commands={telegramCommands}
          />
        )}
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 border-t border-gray-800 mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-white font-bold mb-4">Sniper Bot</h3>
              <p className="text-gray-400 text-sm">Advanced Solana token sniping with MEV protection</p>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Features</h4>
              <ul className="text-gray-400 text-sm space-y-2">
                <li>Anti-MEV Protection</li>
                <li>Rug Pull Detection</li>
                <li>Auto Trading</li>
                <li>Telegram Alerts</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Stats</h4>
              <ul className="text-gray-400 text-sm space-y-2">
                <li>Total Volume: $45.6K</li>
                <li>Success Rate: 68.5%</li>
                <li>Active Users: 127</li>
                <li>Tokens Tracked: 1,842</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Support</h4>
              <ul className="text-gray-400 text-sm space-y-2">
                <li>Documentation</li>
                <li>Telegram Group</li>
                <li>Discord</li>
                <li>GitHub</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-800 text-center text-gray-500 text-sm">
            © 2024 Solana Sniper Bot. Trade at your own risk.
          </div>
        </div>
      </footer>
    </div>
  );
}