import React, { useState } from 'react';

interface Position {
  id: string;
  token: string;
  symbol: string;
  entryPrice: number;
  currentPrice: number;
  amount: number;
  pnl: number;
  pnlPercent: number;
  timestamp: number;
  status: 'active' | 'closed' | 'pending';
}

interface PositionManagerProps {
  positions: Position[];
  onClosePosition: (id: string) => void;
  onUpdateStopLoss: (id: string, value: number) => void;
  onUpdateTakeProfit: (id: string, value: number) => void;
}

export const PositionManager: React.FC<PositionManagerProps> = ({
  positions,
  onClosePosition,
  onUpdateStopLoss,
  onUpdateTakeProfit
}) => {
  const [selectedPosition, setSelectedPosition] = useState<string | null>(null);

  const getPnLColor = (pnl: number) => {
    return pnl >= 0 ? 'text-green-400' : 'text-red-400';
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'active': return 'bg-green-900 text-green-400';
      case 'closed': return 'bg-gray-900 text-gray-400';
      case 'pending': return 'bg-yellow-900 text-yellow-400';
      default: return 'bg-gray-900 text-gray-400';
    }
  };

  return (
    <div className="bg-gray-900 rounded-lg p-6 border border-gray-800">
      <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
        <span className="mr-3">📊</span> Active Positions
      </h2>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-gray-400 border-b border-gray-800">
              <th className="text-left py-3 px-2">Token</th>
              <th className="text-right py-3 px-2">Entry</th>
              <th className="text-right py-3 px-2">Current</th>
              <th className="text-right py-3 px-2">Amount</th>
              <th className="text-right py-3 px-2">P&L</th>
              <th className="text-center py-3 px-2">Status</th>
              <th className="text-center py-3 px-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {positions.map((position) => (
              <tr key={position.id} className="border-b border-gray-800 hover:bg-gray-800">
                <td className="py-3 px-2">
                  <div>
                    <div className="text-white font-bold">{position.symbol}</div>
                    <div className="text-gray-500 text-xs truncate w-24">{position.token}</div>
                  </div>
                </td>
                <td className="text-right py-3 px-2 text-gray-300 font-mono">
                  ${position.entryPrice.toFixed(6)}
                </td>
                <td className="text-right py-3 px-2 text-white font-mono">
                  ${position.currentPrice.toFixed(6)}
                </td>
                <td className="text-right py-3 px-2 text-purple-400 font-mono">
                  {position.amount} SOL
                </td>
                <td className="text-right py-3 px-2">
                  <div className={getPnLColor(position.pnl)}>
                    <div className="font-bold">${position.pnl.toFixed(2)}</div>
                    <div className="text-xs">{position.pnlPercent > 0 ? '+' : ''}{position.pnlPercent.toFixed(2)}%</div>
                  </div>
                </td>
                <td className="text-center py-3 px-2">
                  <span className={`px-2 py-1 rounded text-xs ${getStatusColor(position.status)}`}>
                    {position.status.toUpperCase()}
                  </span>
                </td>
                <td className="text-center py-3 px-2">
                  <div className="flex gap-1 justify-center">
                    <button
                      onClick={() => setSelectedPosition(position.id)}
                      className="bg-blue-600 hover:bg-blue-500 text-white px-2 py-1 rounded text-xs"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => onClosePosition(position.id)}
                      className="bg-red-600 hover:bg-red-500 text-white px-2 py-1 rounded text-xs"
                    >
                      Close
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {positions.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          No active positions. Start sniping tokens to see them here.
        </div>
      )}
    </div>
  );
};