import React, { useState } from 'react';

interface Settings {
  maxMarketCap: number;
  minLiquidity: number;
  maxSlippage: number;
  autoBuyAmount: number;
  stopLossPercent: number;
  takeProfitPercent: number;
  mevProtection: boolean;
  telegramAlerts: boolean;
}

interface SettingsPanelProps {
  settings: Settings;
  onSave: (settings: Settings) => void;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({ settings, onSave }) => {
  const [localSettings, setLocalSettings] = useState(settings);

  const handleChange = (key: keyof Settings, value: any) => {
    setLocalSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleSave = () => {
    onSave(localSettings);
  };

  return (
    <div className="bg-gray-900 rounded-lg p-6 border border-gray-800">
      <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
        <span className="mr-3">⚙️</span> Sniper Settings
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-gray-400 text-sm mb-2">Max Market Cap ($)</label>
          <input
            type="number"
            value={localSettings.maxMarketCap}
            onChange={(e) => handleChange('maxMarketCap', Number(e.target.value))}
            className="w-full bg-gray-800 text-white rounded px-4 py-2 border border-gray-700 focus:border-green-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-gray-400 text-sm mb-2">Min Liquidity ($)</label>
          <input
            type="number"
            value={localSettings.minLiquidity}
            onChange={(e) => handleChange('minLiquidity', Number(e.target.value))}
            className="w-full bg-gray-800 text-white rounded px-4 py-2 border border-gray-700 focus:border-green-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-gray-400 text-sm mb-2">Max Slippage (%)</label>
          <input
            type="number"
            value={localSettings.maxSlippage}
            onChange={(e) => handleChange('maxSlippage', Number(e.target.value))}
            className="w-full bg-gray-800 text-white rounded px-4 py-2 border border-gray-700 focus:border-green-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-gray-400 text-sm mb-2">Auto Buy Amount (SOL)</label>
          <input
            type="number"
            step="0.1"
            value={localSettings.autoBuyAmount}
            onChange={(e) => handleChange('autoBuyAmount', Number(e.target.value))}
            className="w-full bg-gray-800 text-white rounded px-4 py-2 border border-gray-700 focus:border-green-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-gray-400 text-sm mb-2">Stop Loss (%)</label>
          <input
            type="number"
            value={localSettings.stopLossPercent}
            onChange={(e) => handleChange('stopLossPercent', Number(e.target.value))}
            className="w-full bg-gray-800 text-white rounded px-4 py-2 border border-gray-700 focus:border-green-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-gray-400 text-sm mb-2">Take Profit (%)</label>
          <input
            type="number"
            value={localSettings.takeProfitPercent}
            onChange={(e) => handleChange('takeProfitPercent', Number(e.target.value))}
            className="w-full bg-gray-800 text-white rounded px-4 py-2 border border-gray-700 focus:border-green-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center">
          <input
            type="checkbox"
            checked={localSettings.mevProtection}
            onChange={(e) => handleChange('mevProtection', e.target.checked)}
            className="mr-3 w-5 h-5 text-green-500"
          />
          <label className="text-gray-400">Enable MEV Protection</label>
        </div>

        <div className="flex items-center">
          <input
            type="checkbox"
            checked={localSettings.telegramAlerts}
            onChange={(e) => handleChange('telegramAlerts', e.target.checked)}
            className="mr-3 w-5 h-5 text-green-500"
          />
          <label className="text-gray-400">Telegram Alerts</label>
        </div>
      </div>

      <button
        onClick={handleSave}
        className="mt-6 w-full bg-green-600 hover:bg-green-500 text-white py-3 rounded font-bold transition-colors"
      >
        Save Settings
      </button>
    </div>
  );
};