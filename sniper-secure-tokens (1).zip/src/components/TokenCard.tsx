import React from 'react';
import { TokenMetrics } from '../utils/tokenAnalyzer';

interface TokenCardProps {
  token: TokenMetrics;
  onSnipe: (token: TokenMetrics) => void;
  onAnalyze: (token: TokenMetrics) => void;
}

export const TokenCard: React.FC<TokenCardProps> = ({ token, onSnipe, onAnalyze }) => {
  const getRiskColor = (risk: string) => {
    switch(risk) {
      case 'low': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'high': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getRugScoreColor = (score: number) => {
    if (score < 30) return 'text-green-400';
    if (score < 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-lg p-4 hover:border-green-500 transition-all duration-300 transform hover:scale-105">
      <div className="flex justify-between items-start mb-3">
        <div>
          <h3 className="text-white font-bold text-lg">{token.symbol}</h3>
          <p className="text-gray-500 text-xs truncate w-32">{token.address}</p>
        </div>
        <span className={`text-xs px-2 py-1 rounded ${getRiskColor(token.mevRisk)} bg-gray-800`}>
          MEV: {token.mevRisk.toUpperCase()}
        </span>
      </div>

      <div className="space-y-2 mb-4">
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Market Cap:</span>
          <span className="text-green-400 font-mono">${token.marketCap.toLocaleString()}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Liquidity:</span>
          <span className="text-blue-400 font-mono">${token.liquidity.toLocaleString()}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">24h Volume:</span>
          <span className="text-purple-400 font-mono">${token.volume24h.toLocaleString()}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Holders:</span>
          <span className="text-white font-mono">{token.holders}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Rug Score:</span>
          <span className={`font-mono ${getRugScoreColor(token.rugScore)}`}>{token.rugScore}%</span>
        </div>
      </div>

      <div className="flex gap-2">
        <button
          onClick={() => onSnipe(token)}
          className="flex-1 bg-green-600 hover:bg-green-500 text-white py-2 px-3 rounded text-sm font-bold transition-colors"
        >
          SNIPE
        </button>
        <button
          onClick={() => onAnalyze(token)}
          className="flex-1 bg-blue-600 hover:bg-blue-500 text-white py-2 px-3 rounded text-sm font-bold transition-colors"
        >
          ANALYZE
        </button>
      </div>
    </div>
  );
};