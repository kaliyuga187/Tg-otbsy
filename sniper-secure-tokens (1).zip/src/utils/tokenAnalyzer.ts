export interface TokenMetrics {
  address: string;
  name: string;
  symbol: string;
  marketCap: number;
  liquidity: number;
  volume24h: number;
  holders: number;
  priceChange: number;
  rugScore: number;
  mevRisk: 'low' | 'medium' | 'high';
  timestamp: number;
}

export interface FilterCriteria {
  maxMarketCap: number;
  minLiquidity: number;
  minVolume: number;
  maxRugScore: number;
  minHolders: number;
}

export class TokenAnalyzer {
  private static readonly DEFAULT_FILTERS: FilterCriteria = {
    maxMarketCap: 50000,
    minLiquidity: 5000,
    minVolume: 1000,
    maxRugScore: 30,
    minHolders: 10
  };

  static analyzeToken(token: any): TokenMetrics {
    const rugScore = this.calculateRugScore(token);
    const mevRisk = this.assessMEVRisk(token);
    
    return {
      address: token.address,
      name: token.name || 'Unknown',
      symbol: token.symbol || 'N/A',
      marketCap: token.marketCap || 0,
      liquidity: token.liquidity || 0,
      volume24h: token.volume || 0,
      holders: token.holders || 0,
      priceChange: token.priceChange || 0,
      rugScore,
      mevRisk,
      timestamp: Date.now()
    };
  }

  static calculateRugScore(token: any): number {
    let score = 0;
    
    if (!token.liquidityLocked) score += 30;
    if (token.topHolderPercent > 50) score += 25;
    if (!token.mintDisabled) score += 20;
    if (token.holders < 10) score += 15;
    if (!token.verified) score += 10;
    
    return Math.min(score, 100);
  }

  static assessMEVRisk(token: any): 'low' | 'medium' | 'high' {
    if (token.volume > 100000) return 'high';
    if (token.volume > 10000) return 'medium';
    return 'low';
  }

  static filterTokens(tokens: TokenMetrics[], criteria: FilterCriteria = this.DEFAULT_FILTERS): TokenMetrics[] {
    return tokens.filter(token => 
      token.marketCap <= criteria.maxMarketCap &&
      token.liquidity >= criteria.minLiquidity &&
      token.volume24h >= criteria.minVolume &&
      token.rugScore <= criteria.maxRugScore &&
      token.holders >= criteria.minHolders
    );
  }

  static calculateProfitPotential(token: TokenMetrics): number {
    const liquidityRatio = token.volume24h / token.liquidity;
    const holderScore = Math.min(token.holders / 100, 1);
    const safetyScore = (100 - token.rugScore) / 100;
    
    return (liquidityRatio * 0.4 + holderScore * 0.3 + safetyScore * 0.3) * 100;
  }
}