export const CONTRACTS = {
  SNIPER: '0x2D77ed8F964C04D631cb3b9E8E7803e208f1E43b',
  MEV_PROTECTOR: '0x156d0b38218ecff5CA0F6627720476fF9A99E2A4'
};

export const RPC_ENDPOINTS = {
  MAINNET: 'https://api.mainnet-beta.solana.com',
  DEVNET: 'https://api.devnet.solana.com',
  TESTNET: 'https://api.testnet.solana.com',
  PRIVATE: [
    'https://solana-mainnet.rpc.com',
    'https://solana-api.projectserum.com',
    'https://rpc.ankr.com/solana'
  ]
};

export const DEX_ADDRESSES = {
  RAYDIUM: '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM5H24wFSUt1Mp8',
  ORCA: 'DjVE6JNiYqPL2QXyCUUh8rNjHrbz9hXHNYt99MQ59qw1',
  JUPITER: 'JUP4Fb2cqiRUcaTHdrPC8h2gNsA2ETXiPDD33WcGuJB'
};

export const TOKEN_FILTERS = {
  CONSERVATIVE: {
    maxMarketCap: 25000,
    minLiquidity: 10000,
    maxRugScore: 20,
    minHolders: 50,
    minVolume: 5000
  },
  MODERATE: {
    maxMarketCap: 50000,
    minLiquidity: 5000,
    maxRugScore: 40,
    minHolders: 25,
    minVolume: 2500
  },
  AGGRESSIVE: {
    maxMarketCap: 100000,
    minLiquidity: 2500,
    maxRugScore: 60,
    minHolders: 10,
    minVolume: 1000
  }
};

export const TRADING_PARAMS = {
  DEFAULT_SLIPPAGE: 10,
  MAX_SLIPPAGE: 25,
  MIN_TRADE_AMOUNT: 0.1,
  MAX_TRADE_AMOUNT: 10,
  DEFAULT_TRADE_AMOUNT: 0.5,
  GAS_MULTIPLIER: 1.2,
  DEADLINE_BUFFER: 60000
};

export const EXIT_STRATEGIES = {
  CONSERVATIVE: {
    stopLoss: -10,
    takeProfit: 50,
    timeLimit: 7200000
  },
  MODERATE: {
    stopLoss: -20,
    takeProfit: 100,
    timeLimit: 3600000
  },
  AGGRESSIVE: {
    stopLoss: -30,
    takeProfit: 300,
    timeLimit: 1800000
  }
};

export const TELEGRAM_CONFIG = {
  API_URL: 'https://api.telegram.org',
  WEBHOOK_PATH: '/webhook',
  MAX_MESSAGE_LENGTH: 4096,
  RATE_LIMIT: 30,
  COMMANDS: [
    '/start',
    '/stop',
    '/status',
    '/positions',
    '/settings',
    '/snipe',
    '/close',
    '/stats',
    '/help'
  ]
};

export const UI_CONFIG = {
  REFRESH_INTERVAL: 5000,
  MAX_TOKENS_DISPLAY: 20,
  MAX_POSITIONS_DISPLAY: 10,
  CHART_UPDATE_INTERVAL: 1000,
  NOTIFICATION_DURATION: 5000,
  ANIMATION_DURATION: 300
};

export const ERROR_MESSAGES = {
  CONNECTION_FAILED: 'Failed to connect to Solana network',
  INSUFFICIENT_BALANCE: 'Insufficient SOL balance',
  TRANSACTION_FAILED: 'Transaction failed',
  TOKEN_NOT_FOUND: 'Token not found',
  INVALID_ADDRESS: 'Invalid token address',
  MEV_PROTECTION_FAILED: 'MEV protection failed',
  SLIPPAGE_TOO_HIGH: 'Slippage tolerance exceeded'
};