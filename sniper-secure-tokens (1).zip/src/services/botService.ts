import { TokenMetrics, TokenAnalyzer } from '../utils/tokenAnalyzer';
import { MEVProtection } from '../utils/mevProtection';

export interface BotConfig {
  enabled: boolean;
  scanInterval: number;
  maxConcurrentTrades: number;
  riskLevel: 'conservative' | 'moderate' | 'aggressive';
}

export class BotService {
  private config: BotConfig;
  private scanTimer: NodeJS.Timer | null = null;
  private activeTrades: Map<string, any> = new Map();
  
  constructor(config: BotConfig) {
    this.config = config;
  }

  async start(): Promise<void> {
    if (!this.config.enabled) return;
    
    console.log('🚀 Sniper bot started');
    this.scanTimer = setInterval(() => {
      this.scanForOpportunities();
    }, this.config.scanInterval);
  }

  stop(): void {
    if (this.scanTimer) {
      clearInterval(this.scanTimer);
      this.scanTimer = null;
    }
    console.log('🛑 Sniper bot stopped');
  }

  private async scanForOpportunities(): Promise<void> {
    try {
      const tokens = await this.fetchNewTokens();
      const filtered = TokenAnalyzer.filterTokens(tokens);
      
      for (const token of filtered) {
        if (this.shouldSnipe(token)) {
          await this.executeSnipe(token);
        }
      }
    } catch (error) {
      console.error('Scan error:', error);
    }
  }

  private shouldSnipe(token: TokenMetrics): boolean {
    if (this.activeTrades.size >= this.config.maxConcurrentTrades) {
      return false;
    }
    
    const profitPotential = TokenAnalyzer.calculateProfitPotential(token);
    
    switch (this.config.riskLevel) {
      case 'conservative':
        return profitPotential > 80 && token.rugScore < 20;
      case 'moderate':
        return profitPotential > 60 && token.rugScore < 40;
      case 'aggressive':
        return profitPotential > 40;
      default:
        return false;
    }
  }

  private async executeSnipe(token: TokenMetrics): Promise<void> {
    const tradeId = `${token.address}_${Date.now()}`;
    
    const trade = {
      id: tradeId,
      token: token.address,
      symbol: token.symbol,
      entryTime: Date.now(),
      amount: this.calculateTradeAmount(token),
      status: 'pending'
    };
    
    this.activeTrades.set(tradeId, trade);
    
    try {
      const tx = await MEVProtection.executeWithProtection(
        {
          to: token.address,
          amount: trade.amount,
          data: this.buildSwapData(token)
        },
        token.mevRisk
      );
      
      trade.status = 'active';
      console.log(`✅ Sniped ${token.symbol} - TX: ${tx.txHash}`);
      
      this.monitorPosition(tradeId);
    } catch (error) {
      trade.status = 'failed';
      this.activeTrades.delete(tradeId);
      console.error(`❌ Failed to snipe ${token.symbol}:`, error);
    }
  }

  private calculateTradeAmount(token: TokenMetrics): number {
    const baseAmount = 0.5;
    const riskMultiplier = (100 - token.rugScore) / 100;
    return baseAmount * riskMultiplier;
  }

  private buildSwapData(token: TokenMetrics): any {
    return {
      tokenIn: 'SOL',
      tokenOut: token.address,
      slippage: 10,
      deadline: Date.now() + 60000
    };
  }

  private async monitorPosition(tradeId: string): Promise<void> {
    const trade = this.activeTrades.get(tradeId);
    if (!trade) return;
    
    const checkInterval = setInterval(async () => {
      const shouldExit = await this.checkExitConditions(trade);
      
      if (shouldExit) {
        await this.exitPosition(tradeId);
        clearInterval(checkInterval);
      }
    }, 5000);
  }

  private async checkExitConditions(trade: any): Promise<boolean> {
    const currentPrice = await this.getCurrentPrice(trade.token);
    const entryPrice = trade.entryPrice || 1;
    const priceChange = ((currentPrice - entryPrice) / entryPrice) * 100;
    
    if (priceChange >= 200) return true;
    if (priceChange <= -20) return true;
    if (Date.now() - trade.entryTime > 3600000) return true;
    
    return false;
  }

  private async exitPosition(tradeId: string): Promise<void> {
    const trade = this.activeTrades.get(tradeId);
    if (!trade) return;
    
    try {
      await MEVProtection.executeWithProtection(
        {
          to: trade.token,
          amount: trade.amount,
          data: { action: 'sell' }
        },
        'high'
      );
      
      console.log(`💰 Exited position: ${trade.symbol}`);
    } catch (error) {
      console.error(`Failed to exit ${trade.symbol}:`, error);
    } finally {
      this.activeTrades.delete(tradeId);
    }
  }

  private async fetchNewTokens(): Promise<TokenMetrics[]> {
    return [];
  }

  private async getCurrentPrice(token: string): Promise<number> {
    return Math.random() * 2;
  }

  getActiveTrades(): any[] {
    return Array.from(this.activeTrades.values());
  }

  getStats(): any {
    return {
      activeTrades: this.activeTrades.size,
      isRunning: this.scanTimer !== null,
      config: this.config
    };
  }
}